<template>
  <div class="wrapper">
    <div class="title d-flex">
        <span pt-5 pl-5>Entries - Batch 2</span>
        <div class="image"><img src="../assets/arrow-down-icon.svg" alt="arrow"></div>
    </div>
    <span class="description">Comprises of all that applied for Batch 2</span>
    <b-table
      :items="items"
      :fields="fields"
      head-variant="dark"
      table-variant="light"
      :borderless="true"
    ></b-table>
    <div class="entry-details-overlay" onclick="off()">
      <div class="entry-details">
        <form>
          <div class="profile-picture"></div>
          <div class="title"></div>
          <hr>
          <div class="details">
            <div class="row1">
              <div class="name">
                <label for="name">Name</label>
                <input type="text" id="name" value="Ify Chinke">
              </div>
              <div class="email">
                <label for="email">Email</label>
                <input type="text" id="email" value="ify@enyata.com">
              </div>
            </div>
            <div class="row2">
              <div class="address">
                <label for="address">Address</label>
                <input type="text" id="address" value="3, Sabo Ave, Yaba, Lagos">
              </div>
              <div class="university">
                <label for="university">University</label>
                <input type="text" id="university" value="University of Nigeria, Nsukka">
              </div>
            </div>
            <div class="row3">
              <div class="course">
                <label for="course">Course of study</label>
                <input type="text" id="course" value="Computer Science">
              </div>
              <div class="dob">
                <label for="dob">Date of Birth</label>
                <input type="text" id="dob" value="12/09/19 - 22">
              </div>
            </div>
            <div class="row4">
              <div class="cgpa">
                <label for="cgpa">CGPA</label>
                <input type="text" id="cgpa" value="5.0">
              </div>
              <div class="cv">
                <p>CV</p>
                <span></span>
              </div>
            </div>
            <div class="buttons-div">
              <button id="approve-btn">Approve</button>
              <button id="decline-btn">Decline</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'EntriesTable',
  data() {
    return {
      fields: [
        {
          key: 'name',
          sortable: false,
        },
        {
          key: 'email',
          sortable: false,
        },
        {
          key: 'dob',
          label: 'DOB - Age',
          sortable: true,
        },
        {
          key: 'course',
          sortable: false,
        },
        {
          key: 'university',
          sortable: false,
        },
        {
          key: 'cgpa',
          label: 'CGPA',
          sortable: true,
        },
        {
          key: 'status',
          label: 'Application Status',
          sortable: false,
        },
      ],
      items: [
        {
          name: 'Ify Chinke',
          email: 'ify@enyata.com',
          dob: '12/09/19 - 23',
          address: '3, Sabo Ave, Yaba Lagos',
          university: 'University of Nigeria',
          cgpa: 4.0,
          status: 'pending',
        },
        {
          name: 'Ify Chinke',
          email: 'ify@enyata.com',
          dob: '12/09/19 - 22',
          address: '3, Sabo Ave, Yaba Lagos',
          university: 'University of Nigeria',
          cgpa: 5.0,
          status: 'approved',
        },
        {
          name: 'Ify Chinke',
          email: 'ify@enyata.com',
          dob: '12/09/19 - 22',
          address: '3, Sabo Ave, Yaba Lagos',
          university: 'University of Nigeria',
          cgpa: 5.0,
          status: 'pending',
        },
      ],
    };
  },
};
</script>

<style scoped>
.wrapper {
    padding-right: 1.5rem;
}
.title {
  width: 299px;
  height: 53px;
  font-style: normal;
  font-weight: 300;
  font-size: 43px;
  line-height: 52px;
  letter-spacing: -0.02em;
  color: var(--text-primary);
  margin: 101px 0 55px 42px;
}
.description {
    font-weight: normal;
    font-size: 13px;
    line-height: 16px;
    text-align: left;
    color: var(--text-secondary-small);
}
.wrapper table {
  margin-top: 50px;
  text-align: center;
}
.entry-details {
  width: 600px;
  height: 100vh;
  margin: 0 50px;
}
</style>
