<<<<<<< HEAD
# team-async-portal

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
=======
# team-async-portal
>>>>>>> 6e3b1ba0511d60fa8e13930306f1608ad345f658
